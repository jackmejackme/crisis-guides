// Data structure for 8 specific topics
const countryData = {
  'Sweden': {
    flag: '🇸🇪',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '3 liters per person per day',
        details: 'Store in cool, dark place in sealed containers or jerry cans with tap. Boiling capability if uncertain about quality.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '7-10 days supply of non-perishable',
        details: 'Potatoes, cabbage, carrots, bread, pasta, rice, canned goods, nuts, energy bars, jam, honey. Quick-cook items, some ready-to-eat without heating.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: 'Extra supply at home',
        details: 'Regular prescription medicines. Emergency healthcare available at 1177.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Small denominations',
        details: 'Card machines and ATMs may not work; payment systems may fail.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Battery-powered or wind-up radio',
        details: 'P4 is emergency broadcast channel. Solar cells or generator option.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'General shelter principles',
        details: 'Basements, cellars provide protection.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Mentioned in radiological threats context',
        details: 'Protection against radiation mentioned but not detailed.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Climate risk preparation',
        details: 'Potential for increased flooding due to climate change.'
      }
    }
  },
  'Estonia': {
    flag: '🇪🇪',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '3 liters per person per day minimum',
        details: 'Purification tablets or filters recommended. Boil for 3-5 minutes or use purification tablets.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '7 days minimum; 50% ready-to-eat',
        details: 'Instant soups, crackers, nuts, dried fruit, cookies, canned goods, muesli bars, honey. Can be eaten without cooking.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: '7 days supply',
        details: 'Prescription medicines, painkillers, fever reducers, allergy treatment, anti-inflammatories, cold/flu medication.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Cover family needs for 1 week',
        details: 'Card payments may not work; mobile internet may be disabled.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Battery-operated radio',
        details: 'Listen to hourly news. Car radio, solar cells or generator powered.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'Take shelter in building',
        details: 'Load-bearing walls, floor, away from windows. Behind furniture or under table if available.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Not explicitly mentioned',
        details: 'Radiological threats covered under CBRN section.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Not primary section',
        details: 'Warnings via emergency systems.'
      }
    }
  },
  'Poland': {
    flag: '🇵🇱',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '3 liters per person per day minimum',
        details: 'Bottled water reserve or purification tablets. Boiling or purification tablets.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '3+ days minimum',
        details: 'Canned food, crackers, energy bars, dried fruit, nuts. Ready for consumption (non-perishable).'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: '3+ days supply',
        details: 'Painkillers, anti-inflammatory, anti-nausea, anti-diarrheal drugs, bandages, antiseptics. Hospitals will be overwhelmed in crisis.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Various denominations',
        details: 'Card payments disabled during blackouts; essential reserves needed.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Battery-powered or wind-up radio',
        details: 'Charged phone with powerbank, charger, spare batteries. CB radio or walkie-talkie as additional means.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'Varied by location',
        details: 'Outdoor: Fall to ground, cover head. Indoor: Stay away from windows, near load-bearing walls, in central rooms.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Prepared in CBRN threat section',
        details: 'Mark with CBRN symbols; readiness for radiation exposure.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Detailed section with specific actions',
        details: 'Prepare sandbags, seal doors/windows, move valuables to upper floors. White flag (evacuate), Red flag (medical), Blue flag (food/water needs).'
      }
    }
  },
  'United Kingdom': {
    flag: '🇬🇧',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: 'Clean drinking water vital',
        details: 'Bottled water reserve. If toilets not flushing, use strong plastic bags as makeshift toilet.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: 'Few days minimum supply',
        details: 'Tinned meat, fruit, vegetables, non-perishable goods. No cooking required preferred.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: 'Regular medicines at hand',
        details: 'NHS non-emergency 111 for advice; pharmacies may be unavailable.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Cash reserves',
        details: 'Payment cards and cash machines may not work.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Battery or wind-up radio',
        details: 'Updates during power cut. Portable radio essential.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'General building safety',
        details: 'Less emphasis; focus on utility management.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Not specifically mentioned',
        details: 'UK-specific CBRN measures not detailed in household plan.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Not primary section in household plan',
        details: 'General emergency preparedness applies.'
      }
    }
  },
  'Norway': {
    flag: '🇳🇴',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '20 L/person for 1 week',
        details: 'Clean with 2 caps chlorine per 10L, store dark cool place. Boiling or purification option.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '1 week supply',
        details: 'Room temperature storage: biscuits, cereal, conserves, nuts, chocolate, honey. Non-perishable items.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: '7 days + iodine tablets',
        details: 'Iodine tablets 120mg for children and adults <40, pregnant women. Regular prescription medicines.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Multiple cards + cash',
        details: 'Different payment methods, various denominations. Card systems may fail.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'DAB radio',
        details: 'Battery-powered, solar, or manual wind-up. NRK P1 emergency channel.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'Not primary focus',
        details: 'General building safety principles apply.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: '120mg tablets',
        details: 'For children, adults <40, pregnant/nursing women. Part of emergency kit.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Not primary focus',
        details: 'General crisis preparedness applies.'
      }
    }
  },
  'Germany': {
    flag: '🇩🇪',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '2-3 L/person/day for 10 days',
        details: 'Store in cool dark place. Total 20-30L per person for 10 days supply.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '10 days supply',
        details: 'Non-perishable: cereals, pasta, canned goods, dried fruit, nuts. No refrigeration required.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: 'Regular prescribed medicines',
        details: 'Painkillers, cold remedies, diarrhea medication. Sufficient supply for extended period.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Sufficient reserves',
        details: 'ATMs do not work during power outages. Various denominations needed.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Battery/wind-up VHF or digital',
        details: 'Digital reception. Solar radio or car radio as backup option.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'General building safety',
        details: 'Building safety principles, roof securing, structural awareness.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Not mentioned',
        details: 'No specific guidance provided in national preparedness guide.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: '10 days preparation',
        details: 'Risk assessment, preparedness measures, emergency procedures in place.'
      }
    }
  },
  'Latvia': {
    flag: '🇱🇻',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '3 L/person/day for 3-7 days',
        details: 'Purification tablets recommended. Test water quality beforehand if possible.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '3-7 days supply',
        details: 'Long shelf life: canned goods, root vegetables, pasta, cereals, instant soups.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: 'Pain relief, GI medications',
        details: 'Allergy medications, anti-anxiety, disinfectant, bandages, daily medications.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Weekly family needs',
        details: 'Various denominations. Check nearest ATM location in advance.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Portable radio',
        details: 'Extra batteries essential. CB radio or walkie-talkie as backup.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'Not mentioned',
        details: 'General building safety principles apply.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Not mentioned',
        details: 'CBRN measures not detailed in guide.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Not primary focus',
        details: 'General emergency procedures covered.'
      }
    }
  },
  'Czech Republic': {
    flag: '🇨🇿',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '2 L/person/day for 72 hours',
        details: 'Bottled water or containers. Additional 2L for emergency toilet flushing.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '72 hours supply',
        details: 'Non-perishable: long-life bread, canned meat, cereals, nuts, jam.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: '1 week supply',
        details: 'Pain relief, cold remedies, allergy medication. Prescription medicines.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Various denominations',
        details: 'Card payments do not work during blackouts. Cash essential.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Battery-powered radio',
        details: 'Flashlight and spare batteries included in emergency kit.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'Warning signal system',
        details: 'General warning signal: 140 seconds fluctuating tone for emergencies.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Not mentioned',
        details: 'No specific guidance in national preparedness guide.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Crisis situations covered',
        details: 'Mentioned in emergency response section with general guidance.'
      }
    }
  },
  'Romania': {
    flag: '🇷🇴',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: 'UNSPECIFIED',
        details: 'GAP: Duration not specified like other EU countries (should be 7-10 days).'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: 'BASIC KIT',
        details: 'GAP: No specific durations or quantities (other EU: 3-10 days).'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: 'Personal medicines',
        details: 'GAP: Not detailed compared to other countries.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'VAGUE',
        details: 'GAP: No specific reserve recommendations (other EU: 1 week minimum).'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'AM/FM ONLY',
        details: 'GAP: Communication alternatives not comprehensive.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'SHELTER ONLY',
        details: 'GAP: Limited specific guidance (other EU have detailed procedures).'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'NOT MENTIONED',
        details: 'CRITICAL GAP: No iodine tablet preparedness (every EU country has this).'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'LIMITED',
        details: 'GAP: No evacuation flags system or specific action guidance.'
      }
    }
  },
  'Finland': {
    flag: '🇫🇮',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '3 L/person/day for 7 days',
        details: 'Store in cool place. Boiling capability essential for purification.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '7 days supply',
        details: 'Non-perishable items: canned goods, pasta, rice, dried foods.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: '30 days prescription supply',
        details: 'Painkillers, fever reducers, cold medication. First aid kit.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Cash reserves',
        details: 'Various denominations. Digital payments may not function.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Battery-powered radio',
        details: 'YLE broadcasts emergency information. Backup power source.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'General shelter',
        details: 'Building safety, shelter-in-place procedures.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Available at pharmacies',
        details: 'Part of nuclear preparedness. Distributed in risk areas.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Regional warnings',
        details: 'Climate adaptation measures in place.'
      }
    }
  },
  'Switzerland': {
    flag: '🇨🇭',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '3 L/person/day for 14 days',
        details: 'Store 40+ liters per person. Multiple storage locations recommended.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '14 days supply',
        details: 'Extensive supply: cereals, pasta, rice, canned goods, dried foods, oils.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: '60 days prescription supply',
        details: 'Comprehensive first aid kit. Painkillers, antibiotics, chronic medication.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Substantial reserves',
        details: 'Multiple currencies. Electronic payments may fail.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Multiple systems',
        details: 'VHF radio, DAB+, mobile alerts. Solar/wind-up backup.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'Shelter network',
        details: 'Public shelters with radiation protection. Drop/cover/hold procedures.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Pre-distributed tablets',
        details: 'Iodine tablets distributed to households near nuclear facilities.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Risk zones mapped',
        details: 'Flood preparation in alpine regions. Evacuation plans.'
      }
    }
  },
  'Canada': {
    flag: '🇨🇦',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '1 gallon/person/day (3.78L) for 3 days',
        details: 'Bottled water or containers. Purification tablets recommended.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '3 days minimum',
        details: 'Non-perishable: canned goods, dried foods, energy bars.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: 'Prescription supply + first aid',
        details: 'Pain relievers, antihistamines, prescription medications, first aid kit.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Cash reserves',
        details: 'Small denominations. ATMs may not function.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Battery or hand-crank radio',
        details: 'CBC broadcasts emergency information. Solar option recommended.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'Drop, Cover, Hold On',
        details: 'Detailed earthquake procedures. Regional variations (BC, Quebec).'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Available near nuclear facilities',
        details: 'Pre-distributed in zones near nuclear power plants.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Regional preparedness',
        details: 'Flood risk areas mapped. Seasonal warnings.'
      }
    }
  },
  'Australia': {
    flag: '🇦🇺',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '2 L/person/day for 7 days',
        details: 'Store in cool place. Water tanks common in rural areas.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '7 days supply',
        details: 'Non-perishable foods suitable for hot climate storage.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: 'Regular medications',
        details: 'First aid kit, prescription medicines, snake bite kit (rural).'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Cash reserves',
        details: 'EFTPOS may not work. Various denominations.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Battery-powered radio',
        details: 'ABC broadcasts emergency information. Solar recommended.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'Drop, Cover, Hold',
        details: 'Less frequent but procedures in place.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Not widely distributed',
        details: 'Available near Lucas Heights facility.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Major focus',
        details: 'Flood preparation critical. Cyclone season preparations.'
      }
    }
  },
  'New Zealand': {
    flag: '🇳🇿',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '1-2 L/person/day for 7 days',
        details: 'Water storage tanks common. Purification tablets recommended.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '7 days supply',
        details: 'Non-perishable foods. Consider dietary requirements.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: 'Regular medications',
        details: 'First aid kit, prescription medicines, basic medical supplies.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Cash reserves',
        details: 'EFTPOS may fail. Various denominations.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Battery or wind-up radio',
        details: 'RNZ broadcasts emergency information. Solar option.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'Drop, Cover, Hold',
        details: 'Comprehensive earthquake preparedness. High seismic risk.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Not standard',
        details: 'Limited nuclear facilities. Not widely distributed.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Regional risk',
        details: 'Flood preparation in vulnerable areas. Tsunami awareness.'
      }
    }
  },
  'United States': {
    flag: '🇺🇸',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '1 gallon/person/day (3.78L) for 3 days',
        details: 'FEMA recommendation. Bottled water or sealed containers.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '3 days supply',
        details: 'Non-perishable foods. MREs available. Energy bars, canned goods.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: 'Prescription + first aid',
        details: 'Pain relievers, antibiotics if available, prescription medications.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Cash reserves',
        details: 'Small denominations. ATMs may not function.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'NOAA Weather Radio',
        details: 'Battery or hand-crank. Emergency Alert System broadcasts.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'Drop, Cover, Hold On',
        details: 'Regional procedures. Major focus in West Coast states.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Available near nuclear plants',
        details: 'Pre-distributed within 10-mile radius of facilities.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Regional preparedness',
        details: 'Flood zones mapped. Hurricane preparedness in coastal areas.'
      }
    }
  },
  'Croatia': {
    flag: '🇭🇷',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '2.5 L/person/day for 3-7 days',
        details: 'Bottled water recommended. Boiling capability essential.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '3-7 days supply',
        details: 'Non-perishable: canned goods, pasta, rice, dried foods.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: 'Basic supply',
        details: 'Pain relief, prescription medications, first aid kit.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Cash reserves',
        details: 'Card payments may fail. Various denominations.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Battery-powered radio',
        details: 'HRT broadcasts emergency information. Spare batteries.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'High priority',
        details: 'Post-2020 Zagreb earthquake. Detailed procedures. Drop/cover.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Not standard',
        details: 'Limited guidance due to low nuclear risk.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Regional concern',
        details: 'Flood preparation in river valleys. Warning systems.'
      }
    }
  },
  'Lithuania': {
    flag: '🇱🇹',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '3 L/person/day for 7 days',
        details: 'Purification tablets recommended. Store in cool, dark place.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '7 days supply',
        details: 'Non-perishable: canned goods, cereals, pasta, long shelf-life items.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: '7 days supply',
        details: 'Prescription medicines, painkillers, cold remedies, first aid.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: '1 week family needs',
        details: 'Various denominations. Electronic payments may fail.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Portable radio',
        details: 'Battery-powered with spare batteries. LRT emergency broadcasts.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'General procedures',
        details: 'Low seismic risk. Basic shelter-in-place guidance.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Pre-distributed',
        details: 'Near Ignalina site. Part of nuclear preparedness.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Regional warnings',
        details: 'Flood risk in river areas. Warning systems active.'
      }
    }
  },
  'Hungary': {
    flag: '🇭🇺',
    topics: {
      water: {
        title: 'APĂ POTABILĂ',
        icon: '💧',
        recommendation: '3 L/person/day for 7 days',
        details: 'Bottled water storage. Boiling capability for purification.'
      },
      food: {
        title: 'ALIMENTE',
        icon: '🍽️',
        recommendation: '7 days supply',
        details: 'Non-perishable foods: canned goods, pasta, rice, preserved items.'
      },
      medicine: {
        title: 'MEDICAMENTE',
        icon: '💊',
        recommendation: 'Basic supply',
        details: 'Prescription medications, painkillers, first aid kit.'
      },
      cash: {
        title: 'BANI',
        icon: '💰',
        recommendation: 'Cash reserves',
        details: 'Various denominations. Card systems may fail.'
      },
      radio: {
        title: 'RADIO',
        icon: '📻',
        recommendation: 'Battery-powered radio',
        details: 'Kossuth Rádió emergency channel. Spare batteries essential.'
      },
      earthquake: {
        title: 'CUTREMUR',
        icon: '🏚️',
        recommendation: 'General procedures',
        details: 'Low to moderate seismic risk. Basic safety guidance.'
      },
      iodine: {
        title: 'PASTILE IOD',
        icon: '⚕️',
        recommendation: 'Near Paks plant',
        details: 'Distributed to households near nuclear power plant.'
      },
      floods: {
        title: 'INUNDAȚII',
        icon: '🌊',
        recommendation: 'Danube flood risk',
        details: 'Major focus. Flood barriers, evacuation plans, warning systems.'
      }
    }
  }
};

const topicOrder = ['water', 'food', 'medicine', 'cash', 'radio', 'earthquake', 'iodine', 'floods'];

// Old data structure kept for backwards compatibility
const appData = {
  pillars: [
    {
      id: 'water',
      name: 'Apă Potabilă',
      icon: '💧',
      description: 'Cantitate, Durată Stocare, Metode Purificare',
      countries: [
        { name: 'România', recommendation: '3L/persoană/zi', duration: '72 ore', cost: '50', storage: 'Acasă', purification: 'Fierbere', priority: 'CRITICĂ' },
        { name: 'Polonia', recommendation: '3L/persoană/zi', duration: '3 zile', cost: '50', storage: 'Acasă + vehicul', purification: 'Fierbere + tableta', priority: 'CRITICĂ' },
        { name: 'Germania', recommendation: '3L/persoană/zi', duration: '10 zile', cost: '120', storage: '2-3 locații', purification: 'Filtre + fierbere', priority: 'CRITICĂ' },
        { name: 'Suedia', recommendation: '3L/persoană/zi', duration: '7 zile', cost: '80', storage: 'Acasă + piscină', purification: 'Fierbere', priority: 'CRITICĂ' },
        { name: 'Estonia', recommendation: '3L/persoană/zi', duration: '7 zile', cost: '100', storage: 'Acasă + vehicul', purification: 'Filtre + tableta', priority: 'CRITICĂ' },
        { name: 'Norvegia', recommendation: '3L/persoană/zi', duration: '7 zile', cost: '90', storage: 'Acasă (100L)', purification: 'Filtre + dezinfectant', priority: 'CRITICĂ' },
        { name: 'Elveția', recommendation: '3L/persoană/zi', duration: '14 zile', cost: '150', storage: 'Acasă (200L+)', purification: 'Filtre HEPA + carbon', priority: 'CRITICĂ' },
        { name: 'Finlanda', recommendation: '3L/persoană/zi', duration: '7 zile', cost: '85', storage: 'Acasă', purification: 'Fierbere', priority: 'CRITICĂ' },
        { name: 'UK', recommendation: '2-3L/persoană/zi', duration: '3-5 zile', cost: '60', storage: 'Acasă + vecini', purification: 'Fierbere + filtre', priority: 'CRITICĂ' },
        { name: 'Republica Cehă', recommendation: '3L/persoană/zi', duration: '7 zile', cost: '80', storage: 'Grup vecinătate', purification: 'Filtre', priority: 'CRITICĂ' },
        { name: 'Canada', recommendation: '1 galon/pers/zi (3.78L)', duration: '3 zile min', cost: '70', storage: 'Acasă', purification: 'Filtre + dezinfectant', priority: 'CRITICĂ' },
        { name: 'Australia', recommendation: '2L/persoană/zi', duration: '7 zile', cost: '75', storage: 'Acasă + rezervor', purification: 'Filtre', priority: 'CRITICĂ' },
        { name: 'Noua Zeelandă', recommendation: '1-2L/persoană/zi', duration: '7 zile', cost: '60', storage: 'Acasă', purification: 'Filtre', priority: 'CRITICĂ' },
        { name: 'SUA', recommendation: '1 galon/pers/zi (3.78L)', duration: '3 zile', cost: '50', storage: 'Acasă', purification: 'Fierbere', priority: 'CRITICĂ' },
        { name: 'Croația', recommendation: '2.5L/persoană/zi', duration: '3-7 zile', cost: '65', storage: 'Acasă', purification: 'Fierbere', priority: 'CRITICĂ' },
        { name: 'Lituania', recommendation: '3L/persoană/zi', duration: '7 zile', cost: '85', storage: 'Acasă + grup', purification: 'Filtre', priority: 'CRITICĂ' },
        { name: 'Letonia', recommendation: '3L/persoană/zi', duration: '7 zile', cost: '85', storage: 'Acasă + grup', purification: 'Filtre', priority: 'CRITICĂ' },
        { name: 'Ungaria', recommendation: '3L/persoană/zi', duration: '7 zile', cost: '80', storage: 'Acasă', purification: 'Fierbere', priority: 'CRITICĂ' }
      ]
    },
    {
      id: 'food',
      name: 'Alimente',
      icon: '🍽️',
      description: 'Calorii, Tipuri, Durată, Distribuție',
      countries: [
        { name: 'Germania', duration: '10 zile', recommendation: '2000 kcal/persoană', cost: '300', ready_to_eat: '50%', storage_type: 'Balanced (50/50)', priority: 'CRITICĂ' },
        { name: 'Polonia', duration: '3 zile', recommendation: '2000 kcal/persoană', cost: '100', ready_to_eat: '60%', storage_type: 'Conserve + paste', priority: 'CRITICĂ' },
        { name: 'Suedia', duration: '7 zile', recommendation: '2000 kcal/persoană', cost: '150', ready_to_eat: '70%', storage_type: 'Ready + pasta', priority: 'CRITICĂ' },
        { name: 'Estonia', duration: '7 zile', recommendation: '2000 kcal/persoană', cost: '200', ready_to_eat: '60%', storage_type: 'Conserve + paste', priority: 'CRITICĂ' },
        { name: 'Norvegia', duration: '7 zile', recommendation: '2000 kcal/persoană', cost: '180', ready_to_eat: '50%', storage_type: 'Mixt', priority: 'CRITICĂ' },
        { name: 'Finlanda', duration: '7 zile', recommendation: '2000 kcal/persoană', cost: '170', ready_to_eat: '55%', storage_type: 'Mixt', priority: 'CRITICĂ' },
        { name: 'UK', duration: '3-5 zile', recommendation: '2000 kcal/persoană', cost: '120', ready_to_eat: '60%', storage_type: 'Conserve', priority: 'CRITICĂ' },
        { name: 'Republica Cehă', duration: '7 zile', recommendation: '2000 kcal/persoană', cost: '150', ready_to_eat: '50%', storage_type: 'Mixt', priority: 'CRITICĂ' },
        { name: 'Canada', duration: '3 zile min', recommendation: '2000 kcal/persoană', cost: '100', ready_to_eat: '65%', storage_type: 'Conserve', priority: 'CRITICĂ' },
        { name: 'Australia', duration: '7 zile', recommendation: '2000 kcal/persoană', cost: '160', ready_to_eat: '55%', storage_type: 'Mixt', priority: 'CRITICĂ' },
        { name: 'Noua Zeelandă', duration: '7 zile', recommendation: '2000 kcal/persoană', cost: '150', ready_to_eat: '55%', storage_type: 'Mixt', priority: 'CRITICĂ' },
        { name: 'SUA', duration: '3 zile', recommendation: '2000 kcal/persoană', cost: '90', ready_to_eat: '65%', storage_type: 'Conserve', priority: 'CRITICĂ' },
        { name: 'Croația', duration: '3-7 zile', recommendation: '2000 kcal/persoană', cost: '130', ready_to_eat: '50%', storage_type: 'Mixt', priority: 'CRITICĂ' },
        { name: 'Lituania', duration: '7 zile', recommendation: '2000 kcal/persoană', cost: '160', ready_to_eat: '55%', storage_type: 'Mixt', priority: 'CRITICĂ' },
        { name: 'Letonia', duration: '7 zile', recommendation: '2000 kcal/persoană', cost: '160', ready_to_eat: '55%', storage_type: 'Mixt', priority: 'CRITICĂ' },
        { name: 'Ungaria', duration: '7 zile', recommendation: '2000 kcal/persoană', cost: '140', ready_to_eat: '50%', storage_type: 'Mixt', priority: 'CRITICĂ' },
        { name: 'Elveția', duration: '14 zile', recommendation: '2000 kcal/persoană', cost: '350', ready_to_eat: '40%', storage_type: 'Mixt prelungit', priority: 'CRITICĂ' },
        { name: 'România', duration: '72 ore', recommendation: '2000 kcal/persoană', cost: '80', ready_to_eat: '60%', storage_type: 'Conserve', priority: 'CRITICĂ' }
      ]
    },
    {
      id: 'shelters',
      name: 'Adăposturi & Protecție',
      icon: '🏚️',
      description: 'Accesibilitate, Protecție, Durată Maximă',
      countries: [
        { name: 'Elveția', recommendation: 'Adăposturi cu Protecție Radiații', duration: '2+ săptămâni', cost: '0', type: 'Adăposturi cu Protecție Radiații', accessibility: 'Hartă publică - 15 min', max_duration: '2+ săptămâni', cbrn_grade: '10x-100x (radiații)', priority: 'CRITICĂ' },
        { name: 'Polonia', recommendation: 'Public + private', duration: '2 săptămâni', cost: '0', type: 'Public + private', accessibility: 'Hartă + SMS - 30 min', max_duration: '2 săptămâni', cbrn_grade: 'Nespecificat', priority: 'ÎNALTĂ' },
        { name: 'Germania', recommendation: 'Public marcat', duration: '2 săptămâni', cost: '0', type: 'Public marcat', accessibility: 'Hartă online - rapid', max_duration: '2 săptămâni', cbrn_grade: 'Level 1', priority: 'ÎNALTĂ' },
        { name: 'Finlanda', recommendation: 'Public + subteran', duration: '2+ săptămâni', cost: '0', type: 'Subteran', accessibility: 'Hartă + SMS', max_duration: '2+ săptămâni', cbrn_grade: 'CBRN', priority: 'CRITICĂ' },
        { name: 'Suedia', recommendation: 'Public', duration: '2 săptămâni', cost: '0', type: 'Public', accessibility: 'Indicat local', max_duration: '2 săptămâni', cbrn_grade: 'De bază', priority: 'ÎNALTĂ' },
        { name: 'Estonia', recommendation: 'Improvizat + public', duration: '1-2 săptămâni', cost: '0', type: 'Mixt', accessibility: 'Informare locală', max_duration: '1-2 săptămâni', cbrn_grade: 'Variabil', priority: 'MEDIE' },
        { name: 'Norvegia', recommendation: 'Public', duration: '1-2 săptămâni', cost: '0', type: 'Public', accessibility: 'Indicat', max_duration: '1-2 săptămâni', cbrn_grade: 'De bază', priority: 'MEDIE' },
        { name: 'România', recommendation: 'Informații minime', duration: 'Nespecificat', cost: '0', type: 'Nespecificat', accessibility: 'Nespecificat', max_duration: 'Nespecificat', cbrn_grade: 'Nespecificat', priority: 'MEDIE' }
      ]
    },
    {
      id: 'communications',
      name: 'Comunicații',
      icon: '📡',
      description: 'Sisteme Redundante, Rază, Backup',
      countries: [
        { name: 'Elveția', recommendation: 'Mobil + SMS', cost: '500', primary: 'Mobil + SMS', secondary: 'Radio VHF', tertiary: 'Sirene + broadcast', range_km: '20+ km', priority: 'ÎNALTĂ' },
        { name: 'Polonia', recommendation: 'Mobil + SMS', cost: '300', primary: 'Mobil + SMS', secondary: 'Radio + sirene', tertiary: 'Stație poliție', range_km: '20+ km', priority: 'ÎNALTĂ' },
        { name: 'Estonia', recommendation: 'Mobil + app', cost: '400', primary: 'Mobil + app', secondary: 'Radio + SMS', tertiary: 'Direct contact', range_km: '20+ km', priority: 'ÎNALTĂ' },
        { name: 'Germania', recommendation: 'Mobil + radio', cost: '350', primary: 'Mobil', secondary: 'Radio', tertiary: 'Sirene', range_km: '15+ km', priority: 'ÎNALTĂ' },
        { name: 'Suedia', recommendation: 'Mobil + broadcast', cost: '320', primary: 'Mobil', secondary: 'Broadcast', tertiary: 'Radio', range_km: '20+ km', priority: 'ÎNALTĂ' },
        { name: 'Finlanda', recommendation: 'Mobil + radio', cost: '380', primary: 'Mobil', secondary: 'Radio', tertiary: 'Broadcast', range_km: '20+ km', priority: 'ÎNALTĂ' },
        { name: 'Norvegia', recommendation: 'Mobil + radio', cost: '340', primary: 'Mobil', secondary: 'Radio', tertiary: 'Sirene', range_km: '20+ km', priority: 'ÎNALTĂ' },
        { name: 'România', recommendation: 'Mobil', cost: '150', primary: 'Mobil', secondary: 'Radio basic', tertiary: 'Nespecificat', range_km: '10 km', priority: 'MEDIE' }
      ]
    },
    {
      id: 'healthcare',
      name: 'Sănătate & Medicamente',
      icon: '💊',
      description: 'Prescripții, OTC, first aid, cost total',
      countries: [
        { name: 'Germania', recommendation: '90 zile prescripții', duration: '90 zile', cost: '500', prescriptions_days: '90 zile', otc_items: '15+ tipuri', first_aid: 'Complet', storage_location: 'Acasă + vehicul', priority: 'CRITICĂ' },
        { name: 'Polonia', recommendation: '30+ zile prescripții', duration: '30+ zile', cost: '300', prescriptions_days: '30+ zile', otc_items: '10+ tipuri', first_aid: 'Standard', storage_location: 'Acasă', priority: 'CRITICĂ' },
        { name: 'Estonia', recommendation: '30 zile prescripții', duration: '30 zile', cost: '400', prescriptions_days: '30 zile', otc_items: '15+ tipuri', first_aid: 'Complet', storage_location: 'Acasă + grup', priority: 'CRITICĂ' },
        { name: 'Suedia', recommendation: '30 zile prescripții', duration: '30 zile', cost: '380', prescriptions_days: '30 zile', otc_items: '12+ tipuri', first_aid: 'Complet', storage_location: 'Acasă', priority: 'CRITICĂ' },
        { name: 'Norvegia', recommendation: '30 zile prescripții', duration: '30 zile', cost: '400', prescriptions_days: '30 zile', otc_items: '12+ tipuri', first_aid: 'Complet', storage_location: 'Acasă', priority: 'CRITICĂ' },
        { name: 'Finlanda', recommendation: '30 zile prescripții', duration: '30 zile', cost: '370', prescriptions_days: '30 zile', otc_items: '12+ tipuri', first_aid: 'Complet', storage_location: 'Acasă', priority: 'CRITICĂ' },
        { name: 'Elveția', recommendation: '60 zile prescripții', duration: '60 zile', cost: '550', prescriptions_days: '60 zile', otc_items: '18+ tipuri', first_aid: 'Avansat', storage_location: 'Acasă + adăpost', priority: 'CRITICĂ' },
        { name: 'România', recommendation: '14 zile prescripții', duration: '14 zile', cost: '200', prescriptions_days: '14 zile', otc_items: '8+ tipuri', first_aid: 'Basic', storage_location: 'Acasă', priority: 'CRITICĂ' }
      ]
    },
    {
      id: 'psych_info',
      name: 'Sănătate Psihică',
      icon: '🧠',
      description: 'Dezinformare, Gestionare Stres, Resurse',
      countries: [
        { name: 'Estonia', recommendation: 'EXPERT - STOP test', cost: '0', disinformation_framework: 'EXPERT - STOP test', stress_management: 'CUPRINZĂTOR', mental_health_resources: 'Hotline 24/7', maturity_level: 'FOARTE RIDICAT', priority: 'MEDIE' },
        { name: 'Croația', recommendation: 'De bază', cost: '0', disinformation_framework: 'De bază', stress_management: 'FOCUS PTSD', mental_health_resources: 'Clinic + terapie', maturity_level: 'ÎNALT (post-conflict)', priority: 'MEDIE' },
        { name: 'Polonia', recommendation: 'Cuprinzător', cost: '0', disinformation_framework: 'Cuprinzător', stress_management: 'Menționat', mental_health_resources: 'Linie mental', maturity_level: 'Ridicat', priority: 'MEDIE' },
        { name: 'Finlanda', recommendation: 'Media literacy', cost: '0', disinformation_framework: 'Media literacy național', stress_management: 'Standard', mental_health_resources: 'Resurse online', maturity_level: 'FOARTE RIDICAT', priority: 'MEDIE' },
        { name: 'Suedia', recommendation: 'Framework critic', cost: '0', disinformation_framework: 'Critical thinking', stress_management: 'Standard', mental_health_resources: 'Resurse online', maturity_level: 'RIDICAT', priority: 'MEDIE' },
        { name: 'Germania', recommendation: 'Reziliență psihologică', cost: '0', disinformation_framework: 'De bază', stress_management: 'Tehnici coping', mental_health_resources: 'Resurse online', maturity_level: 'MEDIU-RIDICAT', priority: 'MEDIE' },
        { name: 'România', recommendation: 'Basic fake news', cost: '0', disinformation_framework: 'Basic', stress_management: 'Absent', mental_health_resources: 'Minim', maturity_level: 'SCĂZUT', priority: 'MEDIE' }
      ]
    }
  ],
  lacune: [
    { domeniu: 'Apă', romania: '72 ore', european_standard: '7-10 zile', severity: 'CRITIC', gap_percent: '85-90%' },
    { domeniu: 'Alimente', romania: 'Nespecificat', european_standard: '7-10 zile', severity: 'CRITIC', gap_percent: '100%' },
    { domeniu: 'Adăposturi', romania: 'Neclar, fără hartă', european_standard: 'Public + Hartă online', severity: 'CRITIC', gap_percent: '95%' },
    { domeniu: 'Comunicații', romania: 'Nespecificat', european_standard: '3-5 niveluri redundanță', severity: 'CRITIC', gap_percent: '90%' },
    { domeniu: 'Medicamente', romania: 'Nespecificat', european_standard: '30-90 zile + OTC kit', severity: 'CRITIC', gap_percent: '100%' },
    { domeniu: 'Sănătate Psihică', romania: 'Nu menționată', european_standard: 'Secțiune completă dedicate', severity: 'CRITIC', gap_percent: '100%' },
    { domeniu: 'Dezinformare', romania: 'De bază', european_standard: 'Framework STOP (Estonia)', severity: 'ÎNALT', gap_percent: '70%' },
    { domeniu: 'Mobilizare Civile', romania: 'Nespecificat', european_standard: 'Sistem clar (Polonia/Suedia)', severity: 'ÎNALT', gap_percent: '85%' },
    { domeniu: 'Antrenamente', romania: 'Rare/Sporadice', european_standard: 'Regulate anual', severity: 'MEDIU', gap_percent: '80%' }
  ],
  regions: {
    western: { name: 'Western EU', countries: ['Elveția', 'Germania'] },
    nordic: { name: 'Nordic', countries: ['Suedia', 'Norvegia', 'Finlanda'] },
    baltic: { name: 'Baltic', countries: ['Estonia', 'Lituania', 'Letonia'] },
    eastern: { name: 'Eastern EU', countries: ['Polonia', 'Republica Cehă', 'Ungaria', 'Croația'] },
    other: { name: 'Anglo-American & Other', countries: ['UK', 'Canada', 'Australia', 'Noua Zeelandă', 'SUA'] }
  }
};

// Global state
let currentPillar = null;
let currentFilter = 'all';
let sortColumn = -1;
let sortAscending = true;

// Initialize the page
function initializePage() {
  const countries = Object.keys(countryData);
  
  // Populate country selectors
  const country1Select = document.getElementById('country1Select');
  const country2Select = document.getElementById('country2Select');
  const deepDiveSelect = document.getElementById('deepDiveSelect');
  
  countries.forEach(country => {
    const option1 = document.createElement('option');
    option1.value = country;
    option1.textContent = `${countryData[country].flag} ${country}`;
    country1Select.appendChild(option1);
    
    const option2 = document.createElement('option');
    option2.value = country;
    option2.textContent = `${countryData[country].flag} ${country}`;
    country2Select.appendChild(option2);
    
    const option3 = document.createElement('option');
    option3.value = country;
    option3.textContent = `${countryData[country].flag} ${country}`;
    deepDiveSelect.appendChild(option3);
  });
}

// Update comparison table
function updateComparison() {
  const country1 = document.getElementById('country1Select').value;
  const country2 = document.getElementById('country2Select').value;
  
  if (!country1 || !country2) {
    document.getElementById('comparisonTable').style.display = 'none';
    return;
  }
  
  document.getElementById('comparisonTable').style.display = 'block';
  document.getElementById('country1Name').textContent = `${countryData[country1].flag} ${country1}`;
  document.getElementById('country2Name').textContent = `${countryData[country2].flag} ${country2}`;
  
  const tbody = document.getElementById('comparisonTableBody');
  tbody.innerHTML = '';
  
  topicOrder.forEach(topicKey => {
    const topic1 = countryData[country1].topics[topicKey];
    const topic2 = countryData[country2].topics[topicKey];
    
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td style="font-weight: var(--font-weight-semibold); background: var(--color-surface);"><span style="margin-right: 8px;">${topic1.icon}</span>${topic1.title}</td>
      <td>
        <div style="margin-bottom: 8px;"><strong>Recomandare:</strong> ${topic1.recommendation}</div>
        <div style="color: var(--color-text-secondary); font-size: var(--font-size-sm);">${topic1.details}</div>
      </td>
      <td>
        <div style="margin-bottom: 8px;"><strong>Recomandare:</strong> ${topic2.recommendation}</div>
        <div style="color: var(--color-text-secondary); font-size: var(--font-size-sm);">${topic2.details}</div>
      </td>
    `;
    tbody.appendChild(tr);
  });
}

// Update deep dive section
function updateDeepDive() {
  const country = document.getElementById('deepDiveSelect').value;
  
  if (!country) {
    document.getElementById('deepDiveContent').style.display = 'none';
    return;
  }
  
  document.getElementById('deepDiveContent').style.display = 'block';
  
  const accordion = document.getElementById('deepDiveAccordion');
  accordion.innerHTML = '';
  
  topicOrder.forEach((topicKey, index) => {
    const topic = countryData[country].topics[topicKey];
    
    const item = document.createElement('div');
    item.className = 'accordion-item';
    
    const header = document.createElement('div');
    header.className = 'accordion-header';
    header.innerHTML = `
      <span><span style="margin-right: 12px; font-size: 24px;">${topic.icon}</span><strong>${topic.title}</strong></span>
      <span class="accordion-icon">▼</span>
    `;
    
    const content = document.createElement('div');
    content.className = 'accordion-content';
    content.innerHTML = `
      <div style="padding: 16px; background: var(--color-bg-3); border-radius: var(--radius-base); margin-bottom: 12px;">
        <p style="margin-bottom: 12px;"><strong>Recomandare:</strong> ${topic.recommendation}</p>
        <p style="color: var(--color-text-secondary); line-height: 1.6;">${topic.details}</p>
      </div>
    `;
    
    header.onclick = () => {
      const wasActive = item.classList.contains('active');
      document.querySelectorAll('.accordion-item').forEach(i => i.classList.remove('active'));
      document.querySelectorAll('.accordion-content').forEach(c => c.classList.remove('active'));
      
      if (!wasActive) {
        item.classList.add('active');
        content.classList.add('active');
      }
    };
    
    item.appendChild(header);
    item.appendChild(content);
    accordion.appendChild(item);
  });
}

// Navigation functions (legacy - kept for compatibility)
function showDashboard() {
  // Not used in new design
}

function showPiloniView() {
  hideAllViews();
  document.getElementById('piloniView').classList.add('active');
  renderPillarGrid();
}

function showCountryView() {
  hideAllViews();
  document.getElementById('countryView').classList.add('active');
  populateCountrySelector();
}

function showLacuneView() {
  hideAllViews();
  document.getElementById('lacuneView').classList.add('active');
  renderLacuneTable();
}

function renderLacuneTable() {
  const tbody = document.getElementById('lacuneTableBody');
  tbody.innerHTML = '';
  
  appData.lacune.forEach(lacuna => {
    const tr = document.createElement('tr');
    const severityClass = getPriorityClass(lacuna.severity);
    
    tr.innerHTML = `
      <td><strong>${lacuna.domeniu}</strong></td>
      <td style="color: var(--color-error);">${lacuna.romania}</td>
      <td style="color: var(--color-success);">${lacuna.european_standard}</td>
      <td><span class="priority-badge ${severityClass}">${lacuna.severity}</span></td>
      <td><strong>${lacuna.gap_percent}</strong></td>
    `;
    
    tbody.appendChild(tr);
  });
}

function hideAllViews() {
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
}

// Pillar functions
function renderPillarGrid() {
  const grid = document.getElementById('pillarGrid');
  grid.innerHTML = '';
  
  appData.pillars.forEach(pillar => {
    const card = document.createElement('div');
    card.className = 'pillar-card';
    card.onclick = () => showPillarDetails(pillar.id);
    
    card.innerHTML = `
      <div class="pillar-icon">${pillar.icon}</div>
      <h3>${pillar.name}</h3>
      <p>${pillar.description}</p>
      <button class="btn btn-primary">Vizualizează Detalii</button>
    `;
    
    grid.appendChild(card);
  });
}

function showPillarDetails(pillarId) {
  currentPillar = appData.pillars.find(p => p.id === pillarId);
  if (!currentPillar) return;
  
  document.getElementById('pillarGrid').style.display = 'none';
  document.getElementById('pillarDetails').style.display = 'block';
  document.getElementById('pillarDetailsTitle').textContent = `${currentPillar.icon} ${currentPillar.name}`;
  
  setupFilterButtons();
  renderPillarTable();
}

function closePillarDetails() {
  document.getElementById('pillarDetails').style.display = 'none';
  document.getElementById('pillarGrid').style.display = 'grid';
  currentPillar = null;
  currentFilter = 'all';
}

function setupFilterButtons() {
  const buttons = document.querySelectorAll('.filter-btn');
  buttons.forEach(btn => {
    btn.onclick = () => {
      buttons.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      currentFilter = btn.dataset.region;
      renderPillarTable();
    };
  });
}

function renderPillarTable() {
  if (!currentPillar) return;
  
  const tbody = document.getElementById('pillarTableBody');
  tbody.innerHTML = '';
  
  let countries = currentPillar.countries;
  
  // Filter by region
  if (currentFilter !== 'all') {
    const regionCountries = appData.regions[currentFilter].countries;
    countries = countries.filter(c => regionCountries.includes(c.name));
  }
  
  countries.forEach(country => {
    const tr = document.createElement('tr');
    const priorityClass = getPriorityClass(country.priority);
    
    // Build details column based on available data
    let details = country.duration || '';
    if (country.storage) details = country.storage;
    if (country.type) details = country.type;
    if (country.primary) details = country.primary;
    if (country.prescriptions_days) details = country.prescriptions_days;
    if (country.disinformation_framework) details = country.disinformation_framework;
    
    tr.innerHTML = `
      <td><strong>${country.name}</strong></td>
      <td>${country.recommendation}</td>
      <td>${details}</td>
      <td>${country.cost} EUR</td>
      <td><span class="priority-badge ${priorityClass}">${country.priority}</span></td>
    `;
    
    tbody.appendChild(tr);
  });
}

function getPriorityClass(priority) {
  if (priority === 'CRITICĂ' || priority === 'CRITIC') return 'priority-critical';
  if (priority === 'ÎNALTĂ' || priority === 'ÎNALT') return 'priority-high';
  return 'priority-medium';
}

function sortTable(columnIndex) {
  if (!currentPillar) return;
  
  const tbody = document.getElementById('pillarTableBody');
  const rows = Array.from(tbody.querySelectorAll('tr'));
  
  if (sortColumn === columnIndex) {
    sortAscending = !sortAscending;
  } else {
    sortColumn = columnIndex;
    sortAscending = true;
  }
  
  rows.sort((a, b) => {
    const aVal = a.cells[columnIndex].textContent.trim();
    const bVal = b.cells[columnIndex].textContent.trim();
    
    // Try numeric comparison
    const aNum = parseFloat(aVal);
    const bNum = parseFloat(bVal);
    
    if (!isNaN(aNum) && !isNaN(bNum)) {
      return sortAscending ? aNum - bNum : bNum - aNum;
    }
    
    // String comparison
    return sortAscending ? aVal.localeCompare(bVal) : bVal.localeCompare(aVal);
  });
  
  tbody.innerHTML = '';
  rows.forEach(row => tbody.appendChild(row));
}

// Country functions
function populateCountrySelector() {
  const select = document.getElementById('countrySelect');
  const allCountries = new Set();
  
  appData.pillars.forEach(pillar => {
    pillar.countries.forEach(c => allCountries.add(c.name));
  });
  
  const sortedCountries = Array.from(allCountries).sort();
  
  select.innerHTML = '<option value="">-- Alegeți o țară --</option>';
  sortedCountries.forEach(country => {
    const option = document.createElement('option');
    option.value = country;
    option.textContent = country;
    select.appendChild(option);
  });
}

function loadCountryDetails() {
  const countryName = document.getElementById('countrySelect').value;
  if (!countryName) {
    document.getElementById('countryDetails').style.display = 'none';
    return;
  }
  
  document.getElementById('countryDetails').style.display = 'block';
  document.getElementById('countryName').textContent = getCountryFlag(countryName) + ' ' + countryName;
  
  const region = getCountryRegion(countryName);
  document.getElementById('countryRegion').textContent = `Regiune: ${region}`;
  
  renderCountryAccordion(countryName);
}

function getCountryFlag(countryName) {
  const flags = {
    'România': '🇷🇴', 'Polonia': '🇵🇱', 'Germania': '🇩🇪', 'Suedia': '🇸🇪',
    'Estonia': '🇪🇪', 'Norvegia': '🇳🇴', 'Elveția': '🇨🇭', 'Finlanda': '🇫🇮',
    'UK': '🇬🇧', 'Republica Cehă': '🇨🇿', 'Canada': '🇨🇦', 'Australia': '🇦🇺',
    'Noua Zeelandă': '🇳🇿', 'SUA': '🇺🇸', 'Croația': '🇭🇷', 'Lituania': '🇱🇹',
    'Letonia': '🇱🇻', 'Ungaria': '🇭🇺'
  };
  return flags[countryName] || '🌍';
}

function getCountryRegion(countryName) {
  for (const [key, value] of Object.entries(appData.regions)) {
    if (value.countries.includes(countryName)) {
      return value.name;
    }
  }
  return 'Altele';
}

function renderCountryAccordion(countryName) {
  const accordion = document.getElementById('countryAccordion');
  accordion.innerHTML = '';
  
  appData.pillars.forEach((pillar, index) => {
    const countryData = pillar.countries.find(c => c.name === countryName);
    if (!countryData) return;
    
    const item = document.createElement('div');
    item.className = 'accordion-item';
    
    const header = document.createElement('div');
    header.className = 'accordion-header';
    header.innerHTML = `
      <span><strong>${pillar.icon} ${pillar.name}</strong></span>
      <span class="accordion-icon">▼</span>
    `;
    
    const content = document.createElement('div');
    content.className = 'accordion-content';
    content.innerHTML = generateCountryPillarContent(pillar, countryData);
    
    header.onclick = () => {
      const wasActive = item.classList.contains('active');
      document.querySelectorAll('.accordion-item').forEach(i => i.classList.remove('active'));
      document.querySelectorAll('.accordion-content').forEach(c => c.classList.remove('active'));
      
      if (!wasActive) {
        item.classList.add('active');
        content.classList.add('active');
      }
    };
    
    item.appendChild(header);
    item.appendChild(content);
    accordion.appendChild(item);
  });
}

function generateCountryPillarContent(pillar, countryData) {
  let html = '<div style="padding: 12px; background: var(--color-bg-1); border-radius: var(--radius-base); margin-bottom: 12px;">';
  
  // Display all available data fields
  Object.entries(countryData).forEach(([key, value]) => {
    if (key !== 'name') {
      const label = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
      html += `<p><strong>${label}:</strong> ${value}</p>`;
    }
  });
  
  html += '</div>';
  
  // Add comparison note
  html += '<div style="margin-top: 16px; padding: 12px; background: var(--color-bg-3); border-radius: var(--radius-base); border-left: 4px solid var(--color-success);">';
  html += '<p><strong>Comparație:</strong> ';
  
  // Find best performer
  const costField = countryData.cost;
  if (costField) {
    const allCosts = pillar.countries.map(c => parseFloat(c.cost)).filter(c => !isNaN(c));
    const avgCost = allCosts.reduce((a, b) => a + b, 0) / allCosts.length;
    const currentCost = parseFloat(costField);
    
    if (currentCost < avgCost) {
      html += 'Sub media costurilor comparativ cu alte țări.';
    } else if (currentCost > avgCost) {
      html += 'Peste media costurilor - investiție mai mare în acest domeniu.';
    } else {
      html += 'Cost apropiat de media internațională.';
    }
  }
  
  html += '</p></div>';
  
  return html;
}



// Initialize
window.addEventListener('DOMContentLoaded', () => {
  console.log('Crisis Guide Comparison Application loaded');
  console.log('Countries available:', Object.keys(countryData).length);
  initializePage();
});